CREATE TABLE Member(
MemberID INT IDENTITY(1,1) PRIMARY KEY,
MemberAccount nvarchar(30),
MemberPassword nvarchar(15),
MemberName nvarchar(20),
MemberPhoto varchar(100)
);

CREATE TABLE Program(
ProgramID INT IDENTITY(1,1) PRIMARY KEY,
ProgramName nvarchar(50),
ProgramOverview nvarchar(1000)
)

CREATE TABLE ProgramMember(
ProgramMemberID INT IDENTITY(1,1) PRIMARY KEY,
ProgramID INT ,
MemberID INT,
MemberState nvarchar(5),
FOREIGN KEY (ProgramID) REFERENCES Program(ProgramID),
FOREIGN KEY (MemberID) REFERENCES Member(MemberID),
)

CREATE TABLE Intent(
IntentID INT IDENTITY(1,1) PRIMARY KEY,
IntentName nvarchar(50) unique,
MissionCountFinish int,
MissionCountTotal int,
ProgramID INT,
FOREIGN KEY(ProgramID) REFERENCES Program(ProgramID)
)

CREATE TABLE Mission(
MissionID INT IDENTITY(1,1) PRIMARY KEY,
MissionName nvarchar(50) unique,
MisStartTime date,
MisFinishTime date,
MisState nvarchar(10) not null,
MisDescribe nvarchar(500),
IntentID INT,
MemberID INT,
FOREIGN KEY(IntentID) REFERENCES Intent(IntentID),
FOREIGN KEY(MemberID) REFERENCES Member(MemberID)
)

CREATE TABLE ProgramLinkList(
LinkID int IDENTITY(1,1) PRIMARY KEY,
LinkURL nvarchar(50) ,
ProgramID INT ,
LinkTitle nvarchar(50),
FOREIGN KEY(ProgramID) REFERENCES Program(ProgramID)
)

CREATE TABLE Notify(
NotifyID INT IDENTITY(1,1) PRIMARY KEY,
NotifyDate datetime ,
NotifyAction nvarchar(5),
NotifyType  nvarchar(5),
ActionName nvarchar(20),
ProgramID INT,
MemberID INT,
FOREIGN KEY(ProgramID) REFERENCES Program(ProgramID),
FOREIGN KEY(MemberID) REFERENCES Member(MemberID)
)

CREATE TABLE Notebook(
NotebookID INT IDENTITY(1,1) PRIMARY KEY,
NotebookTitle nvarchar(20),
NotebooAddDate DATETIME,
NotebookContent NVARCHAR(200),
ProgramID int,
MemberID int,
foreign key (ProgramID) REFERENCES Program(ProgramID),
FOREIGN KEY (MemberID) REFERENCES Member(MemberID)
)